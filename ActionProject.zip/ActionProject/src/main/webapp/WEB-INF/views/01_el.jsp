<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="com.kh.el.model.dto.Person" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>초강력 JSP</title>
</head>
<body>

	<h1>EL구문 배워보기 정말 조와용</h1>
	<%--
	<!-- 
	<%
		String classRoom = (String)request.getAttribute("classRoom");
		Person student = (Person)request.getAttribute("student");
		
		String academy = (String)session.getAttribute("academy");
		Person lecture = (Person) session.getAttribute("lecture");
	%>
	
	<p>
		학원명 : <%= academy %> <br>
		강의장 : <%= classRoom %> <br>
		강사정보 : <%= lecture.getName() %>, <%= lecture.getAge() %>, <%= lecture.getAddress() %> <br><br>
	
		수강생의 정보
		<ul>
			<li>이름 : <%= student.getName() %></li>
			<li>나이 : <%= student.getAge() %></li>
			<li>주소 : <%= student.getAddress() %></li>
		</u1>
	</p>
	 -->
	 --%>
	 
	 <hr>
	 
	 <h3>EL구문을 이용해서 request / session에 담긴 값들을 출력</h3>
	 
	 <p>
	 	학원명 : ${ academy } <br>
		강의장 : ${ classRoom } <br>
		강사정보 : ${ lecture.name } , ${ lecture.age }, ${ lecture.address } <br>
					<!-- getName() -->
	 	
	 	<!-- 
	 		실제로 필드에 직접 접근 하는것은 불가능
			.name => getName()
			내부적으로 getter메소드를 찾아서 호출해서 값을 출력하는 구조
	 	 -->
	 </p>
	 
	 <hr>
	 
	 <p>없는 키값을 출력하는 경우</p>

	<p>출력식 :<%= request.getAttribute("clasRoom") %> </p>
	<p>EL구문 : ${ clasRoom }</p>
	
	<h3>동일한 key값일 경우</h3>

	키 : ${ key }
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 




</body>
</html>